from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import JobSerializers
from .models import job

@api_view(['GET'])
def home(request):
    l = job.objects.all()
    serializer = JobSerializers(l, many=True)

    return Response(serializer.data)

@api_view(['GET'])
def detail(request, pk):
    l = job.objects.get(id=pk)
    serializer = JobSerializers(l, many=False)
    return Response(serializer.data)

@api_view(['POST'])
def create(request):
    serializer = JobSerializers(data = request.data)

    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

@api_view(['POST'])
def update(request,pk):
    jobs = job.objects.get(id=pk)
    serializer = JobSerializers(instance = jobs,data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)

@api_view(['DELETE'])
def delete(request,pk):
    jobs = job.objects.get(id=pk)
    jobs.delete()
    return Response("Successfully Deleted")


