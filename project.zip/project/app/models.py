from django.db import models


class job(models.Model):
    company = models.CharField(max_length = 200, null = True)
    role = models.CharField(max_length = 200, null  = True)
    exp = models.CharField(max_length=256, choices=[('Fresher', 'Fresher'), ('Experienced', 'Experienced')], default = None)
    application_status = models.CharField(max_length=256, choices=[('Not Applied', 'Not Applied'), ('Applied', 'Applied')], default = None)

    def __str__(self):
        return self.company
    

    
